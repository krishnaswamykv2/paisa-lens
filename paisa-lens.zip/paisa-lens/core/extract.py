"""Extraction: documents -> typed Fields + Transactions with source crops. Owner: Krigv.

Two engines, same output:
  gemma - Gemma 4 reads the page image locally (Ollama) and returns raw values;
          each value is then located on the page to get its bbox and crop.
  text  - deterministic reader of the PDF text layer. Fallback + test baseline.

Gemma only *proposes* values. Whether they are right is decided by verify.py.

CLI:  python -m core.extract samples/case_01 [--engine text|gemma]
"""
from __future__ import annotations

import base64
import io
import json
import os
import re
import sys
from pathlib import Path
from typing import Optional

import requests

from contracts.schemas import (BBox, Direction, DocType, Document, Field,
                               Transaction, ValueType)
from core import pdfio

OUT = Path(os.environ.get("PAISA_OUT", "out"))
OLLAMA = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
GEMMA_MODEL = os.environ.get("PAISA_GEMMA_MODEL", "gemma4")

# label printed on the document -> (field name, value type)
KV_LABELS = {
    "Lender": ("lender", ValueType.text),
    "Borrower": ("borrower", ValueType.text),
    "Loan Account No": ("loan_account", ValueType.account),
    "Sanction Date": ("start_date", ValueType.date),
    "Principal": ("principal", ValueType.money),
    "EMI Amount": ("emi_amount", ValueType.money),
    "Tenure": ("tenure", ValueType.text),
    "Closure Date": ("closure_date", ValueType.date),
    "Outstanding Amount": ("outstanding", ValueType.money),
}
# statement column x-ranges (PDF points)
COLS = {"date": (0, 150), "desc": (150, 360), "debit": (360, 430),
        "credit": (430, 500), "balance": (500, 10_000)}
DATE_RE = re.compile(r"^\d{2}-\d{2}-\d{4}$")


def classify(path: str) -> DocType:
    t = pdfio.page_text(path, 0).upper()
    if "STATEMENT" in t:
        return DocType.statement
    if "CLOSURE" in t or "NO DUES" in t:
        return DocType.closure_letter
    if "LOAN AGREEMENT" in t or "SANCTION" in t:
        return DocType.loan_agreement
    return DocType.unknown


# ---------------- raw readers (engine-specific) ----------------

def _text_kv(path: str, page: int) -> list[tuple[str, str, ValueType, Optional[BBox]]]:
    out = []
    for line in pdfio.lines(path, page):
        label_ws = [w for w in line if w["x0"] < 240]
        value_ws = [w for w in line if w["x0"] >= 240]
        label = " ".join(w["text"] for w in label_ws)
        if label in KV_LABELS and value_ws:
            name, vt = KV_LABELS[label]
            out.append((name, " ".join(w["text"] for w in value_ws), vt, pdfio.union(value_ws)))
    return out


def _text_rows(path: str, page: int) -> list[dict]:
    rows = []
    for line in pdfio.lines(path, page):
        if not DATE_RE.match(line[0]["text"]):
            continue
        cells: dict[str, list[dict]] = {k: [] for k in COLS}
        for w in line:
            for k, (a, b) in COLS.items():
                if a <= w["x0"] < b:
                    cells[k].append(w)
        row = {k: (" ".join(w["text"] for w in ws), pdfio.union(ws) if ws else None)
               for k, ws in cells.items()}
        rows.append(row)
    return rows


GEMMA_PROMPT = """You read one page of an Indian financial document.
Return ONLY JSON, copying text EXACTLY as printed (no reformatting):
{"fields": {"lender": "", "borrower": "", "loan_account": "", "start_date": "",
  "principal": "", "emi_amount": "", "tenure": "", "closure_date": "", "outstanding": ""},
 "transactions": [{"date": "", "description": "", "debit": "", "credit": "", "balance": ""}]}
Leave a value "" if it is not on the page. Include every statement row, including OPENING BALANCE."""


def _gemma_page(path: str, page: int) -> dict:
    img = pdfio.render_page(path, page)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    r = requests.post(f"{OLLAMA}/api/chat", timeout=180, json={
        "model": GEMMA_MODEL, "stream": False, "format": "json",
        "options": {"temperature": 0},
        "messages": [{"role": "user", "content": GEMMA_PROMPT,
                      "images": [base64.b64encode(buf.getvalue()).decode()]}]})
    r.raise_for_status()
    return json.loads(r.json()["message"]["content"])


def _gemma_kv(path, page, data) -> list:
    types = {n: vt for n, vt in KV_LABELS.values()}
    out = []
    for name, raw in (data.get("fields") or {}).items():
        if name in types and raw:
            out.append((name, raw, types[name], pdfio.find_phrase(path, page, raw)))
    return out


def _gemma_rows(path, page, data) -> list[dict]:
    rows = []
    for t in data.get("transactions") or []:
        row = {}
        for k in COLS:
            key = "description" if k == "desc" else k
            raw = (t.get(key) or "").strip()
            row[k] = (raw, pdfio.find_phrase(path, page, raw) if raw else None)
        if row["date"][0]:
            rows.append(row)
    return rows


# ---------------- shared builder ----------------

def _crop_rel(field_id: str) -> str:
    return "crops/" + re.sub(r"[^A-Za-z0-9_-]", "_", field_id) + ".png"


class _Builder:
    def __init__(self, doc_id: str, path: str, engine: str):
        self.doc_id, self.path, self.engine = doc_id, path, engine
        self.fields: list[Field] = []
        self._imgs = {}

    def field(self, fid, name, raw, vtype, page, bbox) -> Field:
        value = pdfio.normalise(raw, vtype) or raw
        crop = None
        if bbox is not None:
            if page not in self._imgs:
                self._imgs[page] = pdfio.render_page(self.path, page)
            crop = _crop_rel(fid)
            pdfio.save_crop(self._imgs[page], bbox, OUT / crop)
        f = Field(field_id=fid, doc_id=self.doc_id, name=name, value=value, raw=raw,
                  type=vtype, page=page, bbox=bbox, crop_path=crop, extractor=self.engine)
        self.fields.append(f)
        return f


def extract(doc_paths: list[str], engine: str = "text"):
    """-> (documents, fields, transactions)"""
    documents, fields, txns = [], [], []
    for path in sorted(doc_paths):
        dtype = classify(path)
        doc_id = Path(path).stem
        documents.append(Document(doc_id=doc_id, path=str(path), doc_type=dtype,
                                  pages=pdfio.page_count(path)))
        b = _Builder(doc_id, path, engine)
        for page in range(pdfio.page_count(path)):
            if engine == "gemma":
                data = _gemma_page(path, page)
                kv, rows = _gemma_kv(path, page, data), _gemma_rows(path, page, data)
            else:
                kv, rows = _text_kv(path, page), _text_rows(path, page)

            if dtype != DocType.statement:
                for name, raw, vt, bbox in kv:
                    b.field(f"{doc_id}:{name}", name, raw, vt, page, bbox)
                continue

            for i, row in enumerate(rows):
                rid = f"{doc_id}:p{page}r{i:02d}"
                desc = row["desc"][0]
                fd = b.field(f"{rid}:date", "txn_date", row["date"][0], ValueType.date, page, row["date"][1])
                fb = b.field(f"{rid}:balance", "txn_balance", row["balance"][0], ValueType.money, page, row["balance"][1])
                if desc.upper().startswith("OPENING BALANCE"):
                    fb.name = "opening_balance"
                    continue
                is_debit = bool(row["debit"][0])
                amt_raw, amt_box = row["debit"] if is_debit else row["credit"]
                fa = b.field(f"{rid}:amount", "txn_amount", amt_raw, ValueType.money, page, amt_box)
                try:
                    txns.append(Transaction(
                        txn_id=rid, doc_id=doc_id, date=fd.value, description=desc,
                        amount=int(fa.value), direction=Direction.debit if is_debit else Direction.credit,
                        balance_after=int(fb.value), field_ids=[fd.field_id, fa.field_id, fb.field_id]))
                except ValueError:
                    pass  # unparseable row: its fields stay, verification flags them
        fields.extend(b.fields)
    return documents, fields, txns


if __name__ == "__main__":
    case = sys.argv[1] if len(sys.argv) > 1 else "samples/case_01"
    eng = sys.argv[sys.argv.index("--engine") + 1] if "--engine" in sys.argv else "text"
    docs, fs, ts = extract([str(p) for p in Path(case).glob("*.pdf")], eng)
    print(json.dumps({"documents": len(docs), "fields": len(fs), "transactions": len(ts),
                      "sample": [f.model_dump() for f in fs[:3]]}, indent=2, default=str))
