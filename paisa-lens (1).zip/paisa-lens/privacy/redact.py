"""Redaction before any optional cloud call. Owner: Gokul. (Working starter by Krigv.)

Nothing leaves the laptop by default. If --opt-in-cloud is ever used, only
the output of redact() may be sent.

CLI:  python -m privacy.redact samples/case_01
"""
from __future__ import annotations

import re
import sys
from pathlib import Path

from contracts.schemas import Field

PAN = re.compile(r"\b[A-Z]{5}\d{4}[A-Z]\b")
LONG_NUM = re.compile(r"\d{6,}")
NAME_FIELDS = {"borrower"}


def redact_text(s: str) -> str:
    s = PAN.sub("[PAN]", s)
    return LONG_NUM.sub(lambda m: "X" * (len(m.group()) - 4) + m.group()[-4:], s)


def redact(fields: list[Field]) -> list[Field]:
    out = []
    for f in fields:
        g = f.model_copy()
        if f.name in NAME_FIELDS:
            g.value = g.raw = "[NAME]"
        else:
            g.raw = redact_text(f.raw)
        g.crop_path = None  # images never leave
        out.append(g)
    return out


if __name__ == "__main__":
    from core.extract import extract
    case = sys.argv[1] if len(sys.argv) > 1 else "samples/case_01"
    _, fields, _ = extract([str(p) for p in Path(case).glob("*.pdf")])
    for f in redact(fields)[:8]:
        print(f.name, "->", f.raw)
