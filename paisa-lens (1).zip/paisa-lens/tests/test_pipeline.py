"""Gate checks on samples/case_01. Run: python -m pytest -q"""
from contracts.schemas import Correction, EvidenceState, Run
from bench.inject import benchmark
from pipeline import run

CASE = "samples/case_01"


def test_run_validates_against_contracts():
    r = run(CASE, corrections=[])
    Run.model_validate(r.model_dump())
    assert len(r.documents) == 3 and len(r.transactions) == 22


def test_clean_case_is_all_confirmed():
    r = run(CASE, corrections=[])
    assert all(e.state == EvidenceState.confirmed for e in r.evidence)


def test_post_closure_emi_found_and_cited():
    r = run(CASE, corrections=[])
    ins = next(i for i in r.insights if i.kind == "post_closure_emi")
    assert ins.amount == 3 * 1245000 and len(ins.dates) == 3
    ids = {f.field_id for f in r.fields}
    assert set(ins.evidence_field_ids) <= ids


def test_correction_reconciles_and_recomputes():
    r = run(CASE, corrections=[Correction(field_id="closure_letter:closure_date", new_value="2026-07-10")])
    e = next(e for e in r.evidence if e.field_id == "closure_letter:closure_date")
    assert e.state == EvidenceState.reconciled
    ins = next(i for i in r.insights if i.kind == "post_closure_emi")
    assert ins.dates == ["2026-08-05"]


def test_benchmark_catches_planted_errors():
    b = benchmark(CASE, n=20, seeds=3)
    assert b["catch_rate"] >= 0.95 and b["false_alarms"] == 0
