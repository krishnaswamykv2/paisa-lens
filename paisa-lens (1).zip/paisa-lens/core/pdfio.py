"""PDF helpers shared by extraction and verification. Owner: Krigv."""
from __future__ import annotations

import re
from datetime import datetime
from functools import lru_cache
from pathlib import Path
from typing import Optional

import pdfplumber
import pypdfium2 as pdfium

from contracts.schemas import BBox, ValueType

RENDER_SCALE = 3  # 216 dpi crops


@lru_cache(maxsize=32)
def _pdf(path: str):
    return pdfplumber.open(path)


def page_count(path: str) -> int:
    return len(_pdf(path).pages)


def page_text(path: str, page: int) -> str:
    return _pdf(path).pages[page].extract_text() or ""


def words(path: str, page: int) -> list[dict]:
    return _pdf(path).pages[page].extract_words()


def lines(path: str, page: int, tol: float = 2.0) -> list[list[dict]]:
    """Words grouped into visual lines, top to bottom, left to right."""
    out: list[list[dict]] = []
    for w in sorted(words(path, page), key=lambda w: (round(w["top"]), w["x0"])):
        if out and abs(out[-1][0]["top"] - w["top"]) <= tol:
            out[-1].append(w)
        else:
            out.append([w])
    return [sorted(l, key=lambda w: w["x0"]) for l in out]


def union(ws: list[dict]) -> BBox:
    return BBox(x0=min(w["x0"] for w in ws), top=min(w["top"] for w in ws),
                x1=max(w["x1"] for w in ws), bottom=max(w["bottom"] for w in ws))


def text_in_bbox(path: str, page: int, bbox: BBox, pad: float = 1.0) -> str:
    """Independent re-read: the words that physically sit inside bbox."""
    inside = [w for w in words(path, page)
              if w["x0"] >= bbox.x0 - pad and w["x1"] <= bbox.x1 + pad
              and w["top"] >= bbox.top - pad and w["bottom"] <= bbox.bottom + pad]
    return " ".join(w["text"] for w in sorted(inside, key=lambda w: (round(w["top"]), w["x0"])))


def find_phrase(path: str, page: int, phrase: str) -> Optional[BBox]:
    """Locate a phrase (e.g. a value Gemma returned) on the page."""
    target = phrase.split()
    if not target:
        return None
    for line in lines(path, page):
        toks = [w["text"] for w in line]
        for i in range(len(toks) - len(target) + 1):
            if toks[i:i + len(target)] == target:
                return union(line[i:i + len(target)])
    return None


def render_page(path: str, page: int, scale: float = RENDER_SCALE):
    doc = pdfium.PdfDocument(path)
    return doc[page].render(scale=scale).to_pil()


def save_crop(img, bbox: BBox, out_path: Path, pad: float = 4.0) -> None:
    s = RENDER_SCALE
    box = (int((bbox.x0 - pad) * s), int((bbox.top - pad) * s),
           int((bbox.x1 + pad) * s), int((bbox.bottom + pad) * s))
    out_path.parent.mkdir(parents=True, exist_ok=True)
    img.crop(box).save(out_path)


# ---- normalisation (shared so extraction and re-read agree on format) ----

_DATE = re.compile(r"^(\d{2})[-/](\d{2})[-/](\d{4})$")


def norm_date(raw: str) -> Optional[str]:
    raw = raw.strip()
    if re.fullmatch(r"\d{4}-\d{2}-\d{2}", raw):  # already ISO (user corrections)
        try:
            return datetime.fromisoformat(raw).date().isoformat()
        except ValueError:
            return None
    m = _DATE.match(raw)
    if not m:
        return None
    d, mth, y = m.groups()
    try:
        return datetime(int(y), int(mth), int(d)).date().isoformat()
    except ValueError:
        return None


def norm_money(raw: str) -> Optional[str]:
    s = raw.replace("Rs", "").replace("INR", "").replace("₹", "").replace(",", "").strip()
    if not re.fullmatch(r"\d+(\.\d{1,2})?", s):
        return None
    rupees, _, paise = s.partition(".")
    return str(int(rupees) * 100 + int((paise + "00")[:2]))


def norm_account(raw: str) -> Optional[str]:
    digits = re.findall(r"\d", raw)
    return "".join(digits[-4:]) if len(digits) >= 4 else None


def normalise(raw: str, vtype: ValueType) -> Optional[str]:
    if vtype == ValueType.date:
        return norm_date(raw)
    if vtype == ValueType.money:
        return norm_money(raw)
    if vtype == ValueType.account:
        return norm_account(raw)
    return raw.strip() or None
