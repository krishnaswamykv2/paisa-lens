"""Extraction: documents -> typed Fields + Transactions with source crops. Owner: Krigv.

Two engines, same output:
  gemma - Gemma 4 reads the page image locally (Ollama) and returns raw values;
          each value is then located on the page to get its bbox and crop.
  text  - deterministic reader of the PDF text layer. Fallback + test baseline.

Gemma only *proposes* values. Whether they are right is decided by verify.py.

CLI:  python -m core.extract samples/case_01 [--engine text|gemma]
"""
from __future__ import annotations

import base64
import io
import json
import os
import re
import sys
from pathlib import Path
from typing import Optional

import requests

from contracts.schemas import (BBox, Direction, DocType, Document, Field,
                               Transaction, ValueType)
from core import pdfio

OUT = Path(os.environ.get("PAISA_OUT", "out"))
OLLAMA = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
GEMMA_MODEL = "gemma4"  # fallback; see _model()

# label printed on the document -> (field name, value type)
KV_LABELS = {
    "Lender": ("lender", ValueType.text),
    "Borrower": ("borrower", ValueType.text),
    "Loan Account No": ("loan_account", ValueType.account),
    "Sanction Date": ("start_date", ValueType.date),
    "Principal": ("principal", ValueType.money),
    "EMI Amount": ("emi_amount", ValueType.money),
    "Tenure": ("tenure", ValueType.text),
    "Closure Date": ("closure_date", ValueType.date),
    "Outstanding Amount": ("outstanding", ValueType.money),
}
# statement column x-ranges (PDF points)
COLS = {"date": (0, 150), "desc": (150, 360), "debit": (360, 430),
        "credit": (430, 500), "balance": (500, 10_000)}
DATE_RE = re.compile(r"^\d{2}-\d{2}-\d{4}$")


def classify(path: str) -> DocType:
    t = pdfio.page_text(path, 0).upper()
    if "STATEMENT" in t:
        return DocType.statement
    if "CLOSURE" in t or "NO DUES" in t:
        return DocType.closure_letter
    if "LOAN AGREEMENT" in t or "SANCTION" in t:
        return DocType.loan_agreement
    return DocType.unknown


# ---------------- raw readers (engine-specific) ----------------

def _text_kv(path: str, page: int) -> list[tuple[str, str, ValueType, Optional[BBox]]]:
    out = []
    for line in pdfio.lines(path, page):
        label_ws = [w for w in line if w["x0"] < 240]
        value_ws = [w for w in line if w["x0"] >= 240]
        label = " ".join(w["text"] for w in label_ws)
        if label in KV_LABELS and value_ws:
            name, vt = KV_LABELS[label]
            out.append((name, " ".join(w["text"] for w in value_ws), vt, pdfio.union(value_ws)))
    return out


def _text_rows(path: str, page: int) -> list[dict]:
    rows = []
    for line in pdfio.lines(path, page):
        if not DATE_RE.match(line[0]["text"]):
            continue
        cells: dict[str, list[dict]] = {k: [] for k in COLS}
        for w in line:
            for k, (a, b) in COLS.items():
                if a <= w["x0"] < b:
                    cells[k].append(w)
        row = {k: (" ".join(w["text"] for w in ws), pdfio.union(ws) if ws else None)
               for k, ws in cells.items()}
        rows.append(row)
    return rows


GEMMA_PROMPT = """You read one page of an Indian financial document.
Return ONLY one JSON object, no prose, no markdown. Copy every value EXACTLY as printed.
{"fields": {"lender": "", "borrower": "", "loan_account": "", "start_date": "",
  "principal": "", "emi_amount": "", "tenure": "", "closure_date": "", "outstanding": ""},
 "transactions": [{"date": "", "description": "", "debit": "", "credit": "", "balance": ""}]}
Rules: leave a value "" if it is not on the page; "transactions" is [] unless the page is a
bank statement table; include every table row in order, including OPENING BALANCE."""
PROMPT_VERSION = "v2"
LABEL_OF = {name: label for label, (name, _) in KV_LABELS.items()}


def _model() -> str:
    """PAISA_GEMMA_MODEL, else the first installed gemma4 tag, else 'gemma4'."""
    if os.environ.get("PAISA_GEMMA_MODEL"):
        return os.environ["PAISA_GEMMA_MODEL"]
    try:
        tags = [m["name"] for m in requests.get(f"{OLLAMA}/api/tags", timeout=5).json().get("models", [])]
        gemma = sorted(t for t in tags if t.startswith("gemma4"))
        if gemma:
            return gemma[0]
    except requests.RequestException:
        pass
    return GEMMA_MODEL


def parse_json_reply(text: str) -> dict:
    """Models wrap JSON in fences or chatter: take the outermost {...}."""
    text = re.sub(r"^```(?:json)?|```$", "", text.strip(), flags=re.M).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        a, b = text.find("{"), text.rfind("}")
        if a == -1 or b <= a:
            raise
        return json.loads(text[a:b + 1])


def _gemma_page(path: str, page: int) -> dict:
    import hashlib
    model = _model()
    key = hashlib.sha256(Path(path).read_bytes() + f"{page}|{model}|{PROMPT_VERSION}".encode()).hexdigest()[:20]
    cache = OUT / "gemma_cache" / f"{key}.json"
    if cache.exists():                       # corrections rerun the pipeline: never re-ask the model
        return json.loads(cache.read_text())
    img = pdfio.render_page(path, page, scale=2)
    buf = io.BytesIO()
    img.save(buf, format="PNG")
    body = {"model": model, "stream": False, "format": "json",
            "options": {"temperature": 0, "num_ctx": 8192},
            "messages": [{"role": "user", "content": GEMMA_PROMPT,
                          "images": [base64.b64encode(buf.getvalue()).decode()]}]}
    last = None
    for _ in range(2):                       # one retry on a malformed reply
        r = requests.post(f"{OLLAMA}/api/chat", timeout=int(os.environ.get("PAISA_GEMMA_TIMEOUT", "600")), json=body)
        r.raise_for_status()
        try:
            data = parse_json_reply(r.json()["message"]["content"])
            break
        except (json.JSONDecodeError, KeyError) as e:
            last = e
    else:
        raise RuntimeError(f"Gemma returned no valid JSON for {Path(path).name} p{page}: {last}")
    cache.parent.mkdir(parents=True, exist_ok=True)
    cache.write_text(json.dumps(data))
    return data


def _locate_kv(path, page, name, raw, vtype):
    """Find the printed value: first by its label on the page, then by its value."""
    label = LABEL_OF.get(name, "").split()
    for line in pdfio.lines(path, page):
        toks = [w["text"] for w in line]
        if label and toks[:len(label)] == label and len(line) > len(label):
            return pdfio.union(line[len(label):])
    box = pdfio.find_phrase(path, page, raw)
    if box:
        return box
    want = pdfio.normalise(raw, vtype)
    for line in pdfio.lines(path, page):
        for i in range(len(line)):
            for j in (i + 1, i + 2):          # "Rs" "12,450.00" spans two words
                seg = line[i:j]
                if want and pdfio.normalise(" ".join(w["text"] for w in seg), vtype) == want:
                    return pdfio.union(seg)
    return None


def _gemma_kv(path, page, data) -> list:
    types = {n: vt for n, vt in KV_LABELS.values()}
    fields = data.get("fields") or {}
    if isinstance(fields, list):              # [{"name":..,"value":..}] variant
        fields = {f.get("name"): f.get("value") for f in fields if isinstance(f, dict)}
    out = []
    for name, raw in fields.items():
        raw = str(raw or "").strip()
        if name in types and raw:
            out.append((name, raw, types[name], _locate_kv(path, page, name, raw, types[name])))
    return out


def _gemma_rows(path, page, data) -> list[dict]:
    """Each Gemma row is pinned to a printed row by date + balance, then its cells
    are taken from that printed row's columns. Gemma's values stay as Gemma's
    claim; verify.py re-reads the cells and catches any mismatch."""
    printed = [l for l in pdfio.lines(path, page) if DATE_RE.match(l[0]["text"])]
    used: set[int] = set()
    rows = []
    for t in data.get("transactions") or []:
        if not isinstance(t, dict):
            continue
        g = {k: str(t.get("description" if k == "desc" else k) or "").strip() for k in COLS}
        if not g["date"]:
            continue
        d, bal = pdfio.norm_date(g["date"]), pdfio.norm_money(g["balance"])
        pick = None
        for score_need in (2, 1):             # date+balance, then date alone
            for i, line in enumerate(printed):
                if i in used:
                    continue
                score = (pdfio.norm_date(line[0]["text"]) == d) + \
                        any(bal and pdfio.norm_money(w["text"]) == bal for w in line)
                if score >= score_need:
                    pick = i
                    break
            if pick is not None:
                break
        cells = {k: None for k in COLS}
        if pick is not None:
            used.add(pick)
            for k, (a, b) in COLS.items():
                ws = [w for w in printed[pick] if a <= w["x0"] < b]
                cells[k] = pdfio.union(ws) if ws else None
        for k in ("debit", "credit"):
            if pdfio.norm_money(g[k]) in (None, "0"):
                g[k] = ""
        rows.append({k: (g[k], cells[k]) for k in COLS})
    return rows


# ---------------- shared builder ----------------

def _crop_rel(field_id: str) -> str:
    return "crops/" + re.sub(r"[^A-Za-z0-9_-]", "_", field_id) + ".png"


class _Builder:
    def __init__(self, doc_id: str, path: str, engine: str):
        self.doc_id, self.path, self.engine = doc_id, path, engine
        self.fields: list[Field] = []
        self._imgs = {}

    def field(self, fid, name, raw, vtype, page, bbox) -> Field:
        value = pdfio.normalise(raw, vtype) or raw
        crop = None
        if bbox is not None:
            if page not in self._imgs:
                self._imgs[page] = pdfio.render_page(self.path, page)
            crop = _crop_rel(fid)
            pdfio.save_crop(self._imgs[page], bbox, OUT / crop)
        f = Field(field_id=fid, doc_id=self.doc_id, name=name, value=value, raw=raw,
                  type=vtype, page=page, bbox=bbox, crop_path=crop, extractor=self.engine)
        self.fields.append(f)
        return f


def extract(doc_paths: list[str], engine: str = "text"):
    """-> (documents, fields, transactions)"""
    documents, fields, txns = [], [], []
    for path in sorted(doc_paths):
        dtype = classify(path)
        doc_id = Path(path).stem
        documents.append(Document(doc_id=doc_id, path=str(path), doc_type=dtype,
                                  pages=pdfio.page_count(path)))
        b = _Builder(doc_id, path, engine)
        for page in range(pdfio.page_count(path)):
            if engine == "gemma":
                data = _gemma_page(path, page)
                kv, rows = _gemma_kv(path, page, data), _gemma_rows(path, page, data)
            else:
                kv, rows = _text_kv(path, page), _text_rows(path, page)

            if dtype != DocType.statement:
                for name, raw, vt, bbox in kv:
                    b.field(f"{doc_id}:{name}", name, raw, vt, page, bbox)
                continue

            for i, row in enumerate(rows):
                rid = f"{doc_id}:p{page}r{i:02d}"
                desc = row["desc"][0]
                fd = b.field(f"{rid}:date", "txn_date", row["date"][0], ValueType.date, page, row["date"][1])
                fb = b.field(f"{rid}:balance", "txn_balance", row["balance"][0], ValueType.money, page, row["balance"][1])
                if desc.upper().startswith("OPENING BALANCE"):
                    fb.name = "opening_balance"
                    continue
                is_debit = bool(row["debit"][0])
                amt_raw, amt_box = row["debit"] if is_debit else row["credit"]
                fa = b.field(f"{rid}:amount", "txn_amount", amt_raw, ValueType.money, page, amt_box)
                try:
                    txns.append(Transaction(
                        txn_id=rid, doc_id=doc_id, date=fd.value, description=desc,
                        amount=int(fa.value), direction=Direction.debit if is_debit else Direction.credit,
                        balance_after=int(fb.value), field_ids=[fd.field_id, fa.field_id, fb.field_id]))
                except ValueError:
                    pass  # unparseable row: its fields stay, verification flags them
        fields.extend(b.fields)
    return documents, fields, txns


if __name__ == "__main__":
    case = sys.argv[1] if len(sys.argv) > 1 else "samples/case_01"
    eng = sys.argv[sys.argv.index("--engine") + 1] if "--engine" in sys.argv else "text"
    docs, fs, ts = extract([str(p) for p in Path(case).glob("*.pdf")], eng)
    print(json.dumps({"documents": len(docs), "fields": len(fs), "transactions": len(ts),
                      "sample": [f.model_dump() for f in fs[:3]]}, indent=2, default=str))
