"""Verification engine: Fields -> Evidence. Owner: Krigv.

The ONLY module allowed to set an evidence state. Deterministic, no model calls.

Checks per field
  parse      raw text normalises to a valid value of its type
  reread     the words physically inside the bbox, re-read from the PDF, give the same value
  balance    statement rows: previous balance + credit - debit == printed balance
  cross_doc  another document agrees (loan account no., EMI amount)
  user       the user corrected this value in the dashboard

State
  confirmed   every check passed
  reconciled  a check failed but another document or the user resolves it
  unresolved  a check failed and nothing resolves it (shown, never hidden)

CLI:  python -m core.verify samples/case_01
"""
from __future__ import annotations

import sys
from collections import Counter, defaultdict
from pathlib import Path

from contracts.schemas import (Check, Direction, Document, DocType, Evidence,
                               EvidenceState, Field, Transaction)
from core import pdfio


def _reread(f: Field, doc_path: str) -> Check:
    if f.bbox is None:
        return Check(name="reread", passed=False, detail="value not found on the page")
    seen = pdfio.text_in_bbox(doc_path, f.page, f.bbox)
    seen_norm = pdfio.normalise(seen, f.type)
    ok = seen_norm == f.value
    return Check(name="reread", passed=ok, detail=f"source reads '{seen}'")


def _parse(f: Field) -> Check:
    if f.extractor == "user":
        v = f.value
        ok = {"text": bool(v.strip()), "money": v.isdigit(), "account": v.isdigit() and len(v) == 4,
              "date": pdfio.norm_date(v) == v}[f.type.value]
        return Check(name="parse", passed=True, detail="user value") if ok else \
            Check(name="parse", passed=False, detail="user value is not a valid " + f.type.value)
    norm = pdfio.normalise(f.raw, f.type)
    return Check(name="parse", passed=norm is not None and norm == f.value,
                 detail=f"'{f.raw}' as {f.type.value}")


def _balance_checks(fields: dict[str, Field], txns: list[Transaction],
                    src: dict[str, str | None]) -> dict[str, Check]:
    """Row invariant on the extracted values, anchored on the previous row's SOURCE balance.
    When a row fails, only the fields whose own re-read failed take the blame."""
    out: dict[str, Check] = {}
    by_doc: dict[str, list[Transaction]] = defaultdict(list)
    for t in txns:
        by_doc[t.doc_id].append(t)
    openings = {f.doc_id: f for f in fields.values() if f.name == "opening_balance"}
    num = lambda v: int(v) if v and v.isdigit() else None
    for doc_id, rows in by_doc.items():
        rows.sort(key=lambda t: t.txn_id)
        o = openings.get(doc_id)
        prev = num(src.get(o.field_id)) if o else None
        for t in rows:
            fa, fb = fields[t.field_ids[1]], fields[t.field_ids[2]]
            amt, bal = num(fa.value), num(fb.value)
            sign = "-" if t.direction == Direction.debit else "+"
            if prev is None or amt is None or bal is None:
                res = {fa.field_id: Check(name="balance", passed=False, detail="cannot compute running balance"),
                       fb.field_id: Check(name="balance", passed=False, detail="cannot compute running balance")}
            else:
                exp = prev - amt if sign == "-" else prev + amt
                detail = f"{prev} {sign} {amt} = {exp}, printed {bal}"
                if exp == bal:
                    res = {fa.field_id: Check(name="balance", passed=True, detail=detail),
                           fb.field_id: Check(name="balance", passed=True, detail=detail)}
                else:
                    culprits = [f for f in (fa, fb) if src.get(f.field_id) != f.value]
                    blamed = culprits or [fa, fb]  # nobody misread -> the document itself is inconsistent
                    res = {f.field_id: Check(name="balance", passed=f not in blamed,
                                             detail=detail if f in blamed else "row error explained by another field")
                           for f in (fa, fb)}
            out.update(res)
            prev = num(src.get(fb.field_id))
    return out


def _cross_doc_checks(fields: dict[str, Field], txns: list[Transaction],
                      src: dict[str, str | None]) -> dict[str, Check]:
    out: dict[str, Check] = {}
    accts = [f for f in fields.values() if f.name == "loan_account"]
    stmt_desc = " ".join(t.description for t in txns)
    for f in accts:
        n = sum(1 for o in accts if o.field_id != f.field_id and src.get(o.field_id) == f.value) \
            + int(f.value in stmt_desc)
        out[f.field_id] = Check(name="cross_doc", passed=n >= 1, detail=f"matched in {n} other source(s)")
    for emi in (f for f in fields.values() if f.name == "emi_amount"):
        acct = fields.get(f"{emi.doc_id}:loan_account")
        last4 = (src.get(acct.field_id) if acct else None) or ""
        debits = [t for t in txns if t.direction == Direction.debit and last4 and last4 in t.description]
        common = Counter(src.get(t.field_ids[1]) for t in debits).most_common(1)
        usual = common[0][0] if common else None
        out[emi.field_id] = Check(name="cross_doc", passed=usual == emi.value,
                                  detail=f"{len(debits)} statement debits for XX{last4}, usual amount {usual}")
        ref = src.get(emi.field_id)
        for t in debits:
            amt_f = fields[t.field_ids[1]]
            out[amt_f.field_id] = Check(name="cross_doc", passed=amt_f.value == ref,
                                        detail=f"loan agreement EMI is {ref}")
    return out


def verify(documents: list[Document], fields: list[Field], txns: list[Transaction]) -> list[Evidence]:
    docs = {d.doc_id: d for d in documents}
    fmap = {f.field_id: f for f in fields}
    rereads = {f.field_id: _reread(f, docs[f.doc_id].path) for f in fields}
    src = {f.field_id: (pdfio.normalise(pdfio.text_in_bbox(docs[f.doc_id].path, f.page, f.bbox), f.type)
                        if f.bbox else None) for f in fields}
    bal = _balance_checks(fmap, txns, src)
    cross = _cross_doc_checks(fmap, txns, src)
    out = []
    for f in fields:
        checks = [_parse(f), rereads[f.field_id]]
        if f.field_id in bal:
            checks.append(bal[f.field_id])
        if f.field_id in cross:
            checks.append(cross[f.field_id])
        if f.extractor == "user":
            src = checks[1].detail
            checks.append(Check(name="user", passed=True, detail=f"user set '{f.value}'; {src}"))

        failed = [c for c in checks if not c.passed]
        if f.extractor == "user" and checks[0].passed:
            state, reason = EvidenceState.reconciled, "corrected by the user"
        elif not failed:
            state, reason = EvidenceState.confirmed, "re-read matches the source; all checks pass"
        elif all(c.name in ("reread", "balance") for c in failed) and \
                any(c.name == "cross_doc" and c.passed for c in checks):
            state, reason = EvidenceState.reconciled, "source disagreed; another document agrees"
        else:
            state = EvidenceState.unresolved
            reason = "; ".join(f"{c.name} failed ({c.detail})" for c in failed)
        out.append(Evidence(field_id=f.field_id, state=state, checks=checks, reason=reason))
    return out


if __name__ == "__main__":
    from core.extract import extract
    case = sys.argv[1] if len(sys.argv) > 1 else "samples/case_01"
    d, f, t = extract([str(p) for p in Path(case).glob("*.pdf")])
    ev = verify(d, f, t)
    print(Counter(e.state.value for e in ev))
    for e in ev:
        if e.state != EvidenceState.confirmed:
            print(e.field_id, e.state.value, e.reason)
