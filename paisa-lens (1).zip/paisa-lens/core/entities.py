"""Entity resolution: link the same loan across documents and time. Owner: Krigv.

Uses only confirmed or reconciled fields.
CLI:  python -m core.entities samples/case_01
"""
from __future__ import annotations

import sys
from pathlib import Path

from contracts.schemas import (Direction, Document, DocType, Evidence,
                               EvidenceState, Field, Loan, Transaction)

USABLE = {EvidenceState.confirmed, EvidenceState.reconciled}


def link_loans(documents: list[Document], fields: list[Field], evidence: list[Evidence],
               txns: list[Transaction]) -> list[Loan]:
    ok = {e.field_id for e in evidence if e.state in USABLE}
    good = {f.field_id: f for f in fields if f.field_id in ok}
    dtype = {d.doc_id: d.doc_type for d in documents}

    def get(doc_id, name):
        return good.get(f"{doc_id}:{name}")

    loans: dict[str, Loan] = {}
    # agreements define loans
    for d in documents:
        if d.doc_type != DocType.loan_agreement:
            continue
        acct = get(d.doc_id, "loan_account")
        if not acct:
            continue
        parts = [acct, get(d.doc_id, "lender"), get(d.doc_id, "start_date"), get(d.doc_id, "emi_amount")]
        loans[acct.value] = Loan(
            loan_id=f"loan-{acct.value}",
            lender=parts[1].value if parts[1] else "unknown lender",
            account_last4=acct.value,
            start_date=parts[2].value if parts[2] else None,
            emi=int(parts[3].value) if parts[3] else None,
            field_ids=[p.field_id for p in parts if p])
    # closure letters attach by account number (create the loan if no agreement)
    for d in documents:
        if d.doc_type != DocType.closure_letter:
            continue
        acct, cd = get(d.doc_id, "loan_account"), get(d.doc_id, "closure_date")
        if not acct:
            continue
        loan = loans.setdefault(acct.value, Loan(loan_id=f"loan-{acct.value}", lender="unknown lender",
                                                 account_last4=acct.value, field_ids=[]))
        loan.field_ids.append(acct.field_id)
        if cd:
            loan.closure_date = cd.value
            loan.field_ids.append(cd.field_id)
    # statement debits that carry the account number = this loan's EMIs
    for loan in loans.values():
        for t in sorted(txns, key=lambda t: t.date):
            if dtype.get(t.doc_id) == DocType.statement and t.direction == Direction.debit \
                    and loan.account_last4 in t.description and all(fid in ok for fid in t.field_ids):
                loan.emi_txn_ids.append(t.txn_id)
    return list(loans.values())


if __name__ == "__main__":
    from core.extract import extract
    from core.verify import verify
    case = sys.argv[1] if len(sys.argv) > 1 else "samples/case_01"
    d, f, t = extract([str(p) for p in Path(case).glob("*.pdf")])
    for loan in link_loans(d, f, verify(d, f, t), t):
        print(loan.model_dump_json(indent=2))
