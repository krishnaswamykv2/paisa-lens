"""Insight engine. Owner: Sridaya. (Working starter by Krigv - extend freely
inside this file; the signature of detect() is part of the boundary.)

Rules only read confirmed / reconciled evidence and always cite field_ids.

  post_closure_emi  EMI debits dated after the loan's closure date
  income_stopped    salary credits stop for 45+ days before the statement ends

CLI:  python -m insights.rules samples/case_01
"""
from __future__ import annotations

import sys
from datetime import date
from pathlib import Path

from contracts.schemas import (Direction, Evidence, EvidenceState, Insight,
                               InsightKind, Loan, Transaction)

USABLE = {EvidenceState.confirmed, EvidenceState.reconciled}
SALARY_WORDS = ("SALARY", "SAL CR", "PAYROLL")


def _rs(paise: int) -> str:
    return f"Rs {paise / 100:,.0f}"


def post_closure_emi(loans: list[Loan], txns: dict[str, Transaction]) -> list[Insight]:
    out = []
    for loan in loans:
        if not loan.closure_date:
            continue
        late = [txns[i] for i in loan.emi_txn_ids if txns[i].date > loan.closure_date]
        if not late:
            continue
        total = sum(t.amount for t in late)
        cites = list(loan.field_ids) + [fid for t in late for fid in t.field_ids[:2]]
        out.append(Insight(
            insight_id=f"post_closure_emi:{loan.loan_id}", kind=InsightKind.post_closure_emi,
            title=f"{len(late)} EMI debits after loan closure: {_rs(total)}",
            loan_id=loan.loan_id, amount=total, dates=[t.date for t in late],
            txn_ids=[t.txn_id for t in late], evidence_field_ids=cites))
    return out


def income_stopped(txns: list[Transaction], gap_days: int = 45) -> list[Insight]:
    if not txns:
        return []
    salaries = sorted((t for t in txns if t.direction == Direction.credit
                       and any(w in t.description.upper() for w in SALARY_WORDS)), key=lambda t: t.date)
    if not salaries:
        return []
    last, end = salaries[-1], max(t.date for t in txns)
    gap = (date.fromisoformat(end) - date.fromisoformat(last.date)).days
    if gap < gap_days:
        return []
    return [Insight(
        insight_id="income_stopped", kind=InsightKind.income_stopped,
        title=f"No salary credit for {gap} days (last on {last.date})",
        amount=last.amount, dates=[last.date, end], txn_ids=[last.txn_id],
        evidence_field_ids=last.field_ids[:2])]


def detect(loans: list[Loan], txns: list[Transaction], evidence: list[Evidence]) -> list[Insight]:
    ok = {e.field_id for e in evidence if e.state in USABLE}
    good = [t for t in txns if all(fid in ok for fid in t.field_ids)]
    return post_closure_emi(loans, {t.txn_id: t for t in good}) + income_stopped(good)


if __name__ == "__main__":
    from core.entities import link_loans
    from core.extract import extract
    from core.verify import verify
    case = sys.argv[1] if len(sys.argv) > 1 else "samples/case_01"
    d, f, t = extract([str(p) for p in Path(case).glob("*.pdf")])
    ev = verify(d, f, t)
    for i in detect(link_loans(d, f, ev, t), t, ev):
        print(i.title, "| cites", len(i.evidence_field_ids), "fields")
