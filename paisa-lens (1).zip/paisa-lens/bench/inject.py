"""Benchmark: plant extraction errors, measure how many verification catches.
Owner: Gokul. (Working starter by Krigv.)

A planted error is "caught" when its field is not marked confirmed.

CLI:  python -m bench.inject samples/case_01 --n 20 --seeds 5
"""
from __future__ import annotations

import json
import random
import sys
from datetime import date, timedelta
from pathlib import Path

from contracts.schemas import EvidenceState, Field, ValueType


def _corrupt(f: Field, rng: random.Random) -> tuple[str, str]:
    v = f.value
    if f.type == ValueType.money and v.isdigit():
        kind = rng.choice(["digit", "swap", "scale"])
        if kind == "digit":
            i = rng.randrange(len(v))
            return v[:i] + str((int(v[i]) + rng.randint(1, 9)) % 10) + v[i + 1:], "wrong digit"
        if kind == "swap" and len(v) > 3:
            i = rng.randrange(len(v) - 3)
            return v[:i] + v[i + 1] + v[i] + v[i + 2:], "swapped digits"
        return str(int(v) * 10), "dropped decimal"
    if f.type == ValueType.date:
        d = date.fromisoformat(v) + timedelta(days=rng.choice([-31, -1, 1, 30]))
        return d.isoformat(), "shifted date"
    if f.type == ValueType.account:
        return v[:-1] + str((int(v[-1]) + 1) % 10), "wrong account digit"
    return v + "X", "garbled text"


def inject(fields: list[Field], n: int, seed: int) -> tuple[list[Field], dict[str, str]]:
    """-> (corrupted copy of fields, {field_id: error kind})"""
    rng = random.Random(seed)
    out = [f.model_copy(deep=True) for f in fields]
    targets = rng.sample([f for f in out if f.type != ValueType.text], min(n, len(out)))
    truth = {}
    for f in targets:
        new, kind = _corrupt(f, rng)
        if new != f.value:
            f.value, f.raw = new, new
            truth[f.field_id] = kind
    return out, truth


def score(evidence, truth: dict[str, str]) -> dict:
    state = {e.field_id: e.state for e in evidence}
    caught = [fid for fid in truth if state.get(fid) != EvidenceState.confirmed]
    false_alarms = [fid for fid, s in state.items() if fid not in truth and s != EvidenceState.confirmed]
    return {"planted": len(truth), "caught": len(caught),
            "catch_rate": round(len(caught) / max(1, len(truth)), 3),
            "false_alarms": len(false_alarms)}


def benchmark(case_dir: str, n: int = 20, seeds: int = 5) -> dict:
    from core.extract import extract
    from core.verify import verify
    docs, fields, txns = extract([str(p) for p in Path(case_dir).glob("*.pdf")])
    runs = []
    for s in range(seeds):
        bad, truth = inject(fields, n, s)  # verify reads values from fields, so txns need no change
        runs.append(score(verify(docs, bad, txns), truth))
    planted = sum(r["planted"] for r in runs)
    caught = sum(r["caught"] for r in runs)
    return {"seeds": seeds, "planted": planted, "caught": caught,
            "catch_rate": round(caught / max(1, planted), 3),
            "false_alarms": sum(r["false_alarms"] for r in runs), "runs": runs}


if __name__ == "__main__":
    case = sys.argv[1] if len(sys.argv) > 1 else "samples/case_01"
    n = int(sys.argv[sys.argv.index("--n") + 1]) if "--n" in sys.argv else 20
    k = int(sys.argv[sys.argv.index("--seeds") + 1]) if "--seeds" in sys.argv else 5
    print(json.dumps(benchmark(case, n, k), indent=2))
