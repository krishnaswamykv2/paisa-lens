"""Pipeline: documents -> out/run.json. Owner: Krigv.

extract -> (apply corrections) -> verify -> link_loans -> detect -> explain

CLI:  python pipeline.py samples/case_01 [--engine text|gemma]
"""
from __future__ import annotations

import json
import os
import sys
from pathlib import Path

from contracts.schemas import Correction, Run
from core import pdfio
from core.entities import link_loans
from core.extract import OUT, extract
from core.verify import verify
from explain.explainer import explain
from insights.rules import detect

CORRECTIONS = OUT / "corrections.json"


def load_corrections() -> list[Correction]:
    if CORRECTIONS.exists():
        return [Correction(**c) for c in json.loads(CORRECTIONS.read_text())]
    return []


def run(case_dir: str, engine: str | None = None, corrections: list[Correction] | None = None) -> Run:
    engine = engine or os.environ.get("PAISA_ENGINE", "text")
    corrections = load_corrections() if corrections is None else corrections
    docs, fields, txns = extract([str(p) for p in Path(case_dir).glob("*.pdf")], engine)

    fix = {c.field_id: c for c in corrections}
    for f in fields:
        if f.field_id in fix:
            new = fix[f.field_id].new_value
            f.value, f.extractor = pdfio.normalise(new, f.type) or new, "user"
    for t in txns:  # transactions mirror their fields
        fd, fa, fb = (next(f for f in fields if f.field_id == i) for i in t.field_ids)
        t.date = fd.value
        if fa.value.isdigit():
            t.amount = int(fa.value)
        if fb.value.isdigit():
            t.balance_after = int(fb.value)

    evidence = verify(docs, fields, txns)
    loans = link_loans(docs, fields, evidence, txns)
    insights = detect(loans, txns, evidence)
    explanations = [explain(i, fields) for i in insights]
    result = Run(case_id=Path(case_dir).name, documents=docs, fields=fields, transactions=txns,
                 evidence=evidence, loans=loans, insights=insights,
                 explanations=explanations, corrections=corrections)
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "run.json").write_text(result.model_dump_json(indent=2))
    return result


if __name__ == "__main__":
    case = sys.argv[1] if len(sys.argv) > 1 else "samples/case_01"
    eng = sys.argv[sys.argv.index("--engine") + 1] if "--engine" in sys.argv else None
    r = run(case, eng)
    from collections import Counter
    print("evidence:", dict(Counter(e.state.value for e in r.evidence)))
    print("loans:", [(l.loan_id, l.closure_date, len(l.emi_txn_ids)) for l in r.loans])
    for i in r.insights:
        print("insight:", i.title)
    print("wrote", OUT / "run.json")
