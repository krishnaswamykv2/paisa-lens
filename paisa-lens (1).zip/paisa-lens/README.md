# Paisa Lens

Every number arrives with its proof. Local-only evidence engine for loan disputes:
Gemma 4 reads documents, deterministic rules decide, the dashboard shows the source crop
and evidence state (confirmed / reconciled / unresolved) for every value.

## Run it (2 minutes)

```bash
pip install -r requirements.txt
python samples/make_case_01.py          # builds the 3 demo PDFs
python pipeline.py samples/case_01      # -> out/run.json
uvicorn server:app --port 8000          # open http://localhost:8000
python -m pytest -q                     # gate checks (5 tests)
```

### Use Gemma 4 instead of the text-layer reader

```bash
ollama pull <your gemma 4 tag>
export PAISA_GEMMA_MODEL=<that tag>
export PAISA_ENGINE=gemma               # extraction via Gemma 4 vision
export PAISA_EXPLAIN=gemma              # explanations via Gemma 4 (template fallback)
uvicorn server:app --port 8000
```

The `gemma` engine has not been tested against a live model yet: test it first (step 1 below).
If Gemma is slow or fails, keep `PAISA_ENGINE=text`. The demo works fully on the text layer.

## The boundary

- Import only from `contracts/schemas.py`. Never import another person's module.
- Need a new field? Ask Krigv. Never edit `schemas.py` locally.
- Gemma decides nothing: only `core/verify.py` sets evidence states.
- Money is integer paise, dates are ISO strings.
- Each module runs alone: `python -m <module> samples/case_01`.

## Who owns what (each file already works; improve inside your own file)

| Owner | Files | Next tasks for today |
| --- | --- | --- |
| Krigv | `contracts/`, `core/`, `pipeline.py` | Test `PAISA_ENGINE=gemma` on the demo laptop; tune the prompt in `core/extract.py` |
| Sridaya | `insights/rules.py`, `explain/explainer.py` | Test `PAISA_EXPLAIN=gemma`; tighten the explainer prompt; add a third rule if time allows |
| Sanjay | `ui/index.html`, `server.py` | Polish the dashboard; record a 60 s backup demo video |
| Gokul | `bench/inject.py`, `privacy/redact.py`, `samples/` | Put the benchmark numbers on the slides; add a second sample case |

## Demo script

1. Open the dashboard: 79 values, all confirmed, 2 findings.
2. Show the post-closure EMI finding (Rs 37,350) and click a cited crop to jump to its row.
3. Show the timeline: 3 red EMIs after the dashed closure line.
4. Edit the closure date to `2026-07-10`. It turns reconciled, and the finding drops to 1 EMI.
5. Click Reset corrections, then Run benchmark: 93/93 planted errors caught, 0 false alarms.

## Layout

```
contracts/schemas.py   shared models (the boundary)
core/extract.py        Gemma 4 or text-layer extraction + source crops
core/verify.py         parse, re-read, balance, cross-document, user checks -> evidence state
core/entities.py       links one loan across agreement, closure letter, statement
insights/rules.py      post-closure EMI, income stopped
explain/explainer.py   plain-language explanation, cites fields only
bench/inject.py        error injection + catch rate
privacy/redact.py      redaction for any opt-in cloud call
server.py, ui/         local dashboard
```

## Gemma 4 setup (Krigv)

```bash
# 1. install Ollama 0.22+ from ollama.com, then:
ollama pull gemma4:e2b                  # ~7 GB; gemma4 (e4b) is ~9.6 GB and needs 12 GB RAM
python scripts/check_gemma.py           # GO / NO-GO verdict in one command
PAISA_ENGINE=gemma PAISA_EXPLAIN=gemma uvicorn server:app --port 8000
```

- Gemma replies are cached in `out/gemma_cache/`, so corrections rerun instantly. Run the
  check once before the demo to warm the cache.
- No model yet? Test the whole Gemma path with the fake server:
  `uvicorn scripts.mock_ollama:app --port 11434` (it misreads one EMI on purpose).
- Demo beat: a Gemma misread shows as **unresolved** and is kept out of the finding.
  Fix it with Edit and it turns **reconciled**, and the finding goes back to the full amount.
