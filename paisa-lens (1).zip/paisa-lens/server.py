"""Local web server for the evidence dashboard. Owner: Sanjay (wiring by Krigv).

Run:  uvicorn server:app --port 8000     then open http://localhost:8000
Everything stays on this machine.
"""
from __future__ import annotations

import json
import shutil
import time
from pathlib import Path

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

import pipeline
from bench.inject import benchmark
from contracts.schemas import Correction
from core.extract import OUT

ROOT = Path(__file__).parent
STATE = {"case": str(ROOT / "samples" / "case_01"), "bench": None}

app = FastAPI(title="Paisa Lens")
OUT.mkdir(parents=True, exist_ok=True)
(OUT / "crops").mkdir(exist_ok=True)
app.mount("/crops", StaticFiles(directory=OUT / "crops"), name="crops")


def _run():
    return json.loads(pipeline.run(STATE["case"]).model_dump_json())


@app.get("/")
def index():
    return FileResponse(ROOT / "ui" / "index.html")


@app.get("/api/run")
def get_run():
    return JSONResponse(_run())


class CorrectionIn(BaseModel):
    field_id: str
    new_value: str
    user_note: str = ""


@app.post("/api/correct")
def correct(c: CorrectionIn):
    items = [x for x in pipeline.load_corrections() if x.field_id != c.field_id]
    items.append(Correction(**c.model_dump()))
    pipeline.CORRECTIONS.write_text(json.dumps([x.model_dump() for x in items], indent=2))
    return JSONResponse(_run())


@app.post("/api/reset")
def reset():
    pipeline.CORRECTIONS.unlink(missing_ok=True)
    return JSONResponse(_run())


@app.post("/api/sample")
def use_sample():
    STATE["case"], STATE["bench"] = str(ROOT / "samples" / "case_01"), None
    pipeline.CORRECTIONS.unlink(missing_ok=True)
    return JSONResponse(_run())


@app.post("/api/upload")
async def upload(files: list[UploadFile] = File(...)):
    pdfs = [f for f in files if f.filename and f.filename.lower().endswith(".pdf")]
    if not pdfs:
        raise HTTPException(400, "upload one or more PDF files")
    case = OUT / "uploads" / time.strftime("case_%H%M%S")
    case.mkdir(parents=True, exist_ok=True)
    for f in pdfs:
        with open(case / Path(f.filename).name, "wb") as fh:
            shutil.copyfileobj(f.file, fh)
    STATE["case"], STATE["bench"] = str(case), None
    pipeline.CORRECTIONS.unlink(missing_ok=True)
    return JSONResponse(_run())


@app.get("/api/bench")
def bench():
    if STATE["bench"] is None:
        STATE["bench"] = benchmark(STATE["case"], n=20, seeds=5)
    return JSONResponse(STATE["bench"])
