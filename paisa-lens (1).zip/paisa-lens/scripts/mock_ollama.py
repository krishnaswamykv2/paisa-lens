"""Fake Ollama server for testing the Gemma path without a model.

Behaves like a small vision model would: wraps JSON in a markdown fence with
chatter, reformats some values (drops commas, writes an ISO date), and misreads
ONE EMI amount (12,450 -> 12,540) so verification has something to catch.

Run (from repo root):  uvicorn scripts.mock_ollama:app --port 11434
"""
import base64
import hashlib
import io
import json
import re
from pathlib import Path

import pdfplumber
from fastapi import FastAPI, Request
from PIL import Image

from core import pdfio

app = FastAPI()
CASE = Path("samples/case_01")


def _fingerprint(img: Image.Image) -> str:
    return hashlib.md5(img.convert("L").resize((64, 90)).tobytes()).hexdigest()


# which rendered page is which document (the pipeline renders at scale 2)
PAGES = {_fingerprint(pdfio.render_page(str(p), 0, scale=2)): p.stem for p in CASE.glob("*.pdf")}

KV = {
    "loan_agreement": {"lender": "FinSure Capital Ltd", "borrower": "Arun Prakash", "loan_account": "XXXXXX7731",
                       "start_date": "2024-06-05",              # model rewrote the date as ISO
                       "principal": "Rs 4,00,000.00", "emi_amount": "Rs 12,450.00", "tenure": "36 months"},
    "closure_letter": {"borrower": "Arun Prakash", "loan_account": "XXXXXX7731", "closure_date": "10-05-2026",
                       "outstanding": "Rs 0.00"},
}


def _statement_rows() -> list[dict]:
    rows = []
    with pdfplumber.open(CASE / "statement.pdf") as pdf:
        for line in pdf.pages[0].extract_text().splitlines():
            m = re.match(r"(\d{2}-\d{2}-\d{4}) (.+?) ([\d,]+\.\d{2})(?: ([\d,]+\.\d{2}))?$", line)
            if not m:
                continue
            date, desc, a, b = m.groups()
            if b is None:
                rows.append({"date": date, "description": desc, "debit": "", "credit": "", "balance": a})
                continue
            credit = "SALARY" in desc
            rows.append({"date": date, "description": desc,
                         "debit": "" if credit else a.replace(",", ""),  # model dropped the commas
                         "credit": a if credit else "", "balance": b})
    for r in rows:
        if r["date"] == "05-06-2026" and "EMI" in r["description"]:
            r["debit"] = "12540.00"                                     # the one misread
    return rows


@app.get("/api/version")
def version():
    return {"version": "0.22.1-mock"}


@app.get("/api/tags")
def tags():
    return {"models": [{"name": "gemma4:e2b"}]}


@app.post("/api/chat")
async def chat(req: Request):
    body = await req.json()
    img = Image.open(io.BytesIO(base64.b64decode(body["messages"][0]["images"][0])))
    doc = PAGES.get(_fingerprint(img))
    if doc == "statement":
        data = {"fields": {}, "transactions": _statement_rows()}
    elif doc in KV:
        data = {"fields": KV[doc], "transactions": []}
    else:
        data = {"fields": {}, "transactions": []}
    content = "Sure! Here is the extracted data:\n```json\n" + json.dumps(data, indent=1) + "\n```"
    return {"message": {"role": "assistant", "content": content}}


@app.post("/api/generate")
async def generate(req: Request):
    return {"response": "Your loan was closed, but EMIs kept being debited afterwards. "
                        "The closure letter and each debit are shown as proof."}
