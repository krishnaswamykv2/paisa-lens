"""One-command Gemma 4 readiness check. Owner: Krigv.

    python scripts/check_gemma.py [samples/case_01]

1. Ollama is running and new enough (>= 0.22)
2. A gemma4 model is installed (and which one is used)
3. Gemma extraction per document, timed
4. Field-by-field comparison against the text-layer engine
5. Evidence states + findings with Gemma, and whether the explainer answers
Ends with a GO / NO-GO verdict for demoing PAISA_ENGINE=gemma.
"""
import os
import re
import shutil
import sys
import time
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import requests  # noqa: E402

from core import extract as ex  # noqa: E402

CASE = sys.argv[1] if len(sys.argv) > 1 else "samples/case_01"
OK, BAD, WARN = "  [ok]  ", "  [FAIL]", "  [warn]"


def step(n, title):
    print(f"\n{n}. {title}")


def main() -> int:
    step(1, f"Ollama at {ex.OLLAMA}")
    try:
        v = requests.get(f"{ex.OLLAMA}/api/version", timeout=5).json()["version"]
    except Exception as e:
        print(BAD, f"not reachable ({e.__class__.__name__}). Start the Ollama app, or run: ollama serve")
        return 1
    major_minor = tuple(int(x) for x in re.findall(r"\d+", v)[:2])
    print(OK if major_minor >= (0, 22) else WARN, f"version {v}" + ("" if major_minor >= (0, 22) else " - update to 0.22+ for Gemma 4"))

    step(2, "Gemma 4 model")
    tags = [m["name"] for m in requests.get(f"{ex.OLLAMA}/api/tags", timeout=5).json().get("models", [])]
    gemma = [t for t in tags if t.startswith("gemma4")]
    if not gemma and not os.environ.get("PAISA_GEMMA_MODEL"):
        print(BAD, "no gemma4 model installed. Run: ollama pull gemma4:e2b")
        return 1
    model = ex._model()
    print(OK, f"using {model}" + (f"  (installed: {', '.join(gemma)})" if gemma else ""))

    step(3, "Gemma extraction, per document (first call loads the model, so it is slowest)")
    shutil.rmtree(ex.OUT / "gemma_cache", ignore_errors=True)
    pdfs = sorted(str(p) for p in Path(CASE).glob("*.pdf"))
    total = 0.0
    for p in pdfs:
        t0 = time.time()
        try:
            for page in range(ex.pdfio.page_count(p)):
                ex._gemma_page(p, page)
        except Exception as e:
            print(BAD, f"{Path(p).name}: {e}")
            return 1
        dt = time.time() - t0
        total += dt
        print(OK, f"{Path(p).name}: {dt:.1f}s")
    print("        total", f"{total:.1f}s (cached now: corrections rerun instantly)")

    step(4, "Gemma vs text-layer engine")
    _, tf, _ = ex.extract(pdfs, "text")
    _, gf, gt = ex.extract(pdfs, "gemma")
    text_vals = {f.field_id: f.value for f in tf}
    gem_vals = {f.field_id: f for f in gf}
    same = sum(1 for k, v in text_vals.items() if k in gem_vals and gem_vals[k].value == v)
    missing = [k for k in text_vals if k not in gem_vals]
    differ = [(k, text_vals[k], gem_vals[k].value) for k in text_vals if k in gem_vals and gem_vals[k].value != text_vals[k]]
    unlocated = [f.field_id for f in gf if f.bbox is None]
    print(OK if same == len(text_vals) else WARN, f"{same}/{len(text_vals)} values identical")
    for k, a, b in differ[:8]:
        print("        differs:", k, f"page={a!r} gemma={b!r}")
    if missing:
        print(WARN, f"{len(missing)} values Gemma did not return, e.g. {missing[:4]}")
    if unlocated:
        print(WARN, f"{len(unlocated)} Gemma values could not be located on the page, e.g. {unlocated[:4]}")

    step(5, "Full pipeline with Gemma")
    import pipeline
    os.environ["PAISA_EXPLAIN"] = "gemma"
    r = pipeline.run(CASE, "gemma", corrections=[])
    states = Counter(e.state.value for e in r.evidence)
    print(OK, "evidence:", dict(states))
    for i in r.insights:
        print(OK, "finding:", i.title)
    engines = {e.engine for e in r.explanations}
    print(OK if "gemma" in engines else WARN, "explainer engine:", ", ".join(engines) or "none")

    coverage = same / max(1, len(text_vals))
    found_emi = any(i.kind == "post_closure_emi" for i in r.insights)
    go = coverage >= 0.8 and found_emi and total < 300
    print("\nVERDICT:", "GO - demo with PAISA_ENGINE=gemma" if go else
          "NO-GO for Gemma extraction - demo with PAISA_ENGINE=text and PAISA_EXPLAIN=gemma")
    if differ or unlocated:
        print("  Note: values where Gemma misread are shown as unresolved/reconciled in the dashboard -")
        print("  that is the verification engine working. Point at one during the demo.")
    return 0 if go else 2


if __name__ == "__main__":
    sys.exit(main())
