"""Paisa Lens shared contracts.

THE BOUNDARY: every module imports only from here and talks through these
objects. Owner: Krigv. Do not add or rename fields locally - ask Krigv.

Conventions
- Dates are ISO strings: "2026-10-23".
- Money is integer paise (Rs 12,450.00 -> 1245000). Never floats.
- Every Insight / Explanation cites the field_ids it rests on.
"""
from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field as PField


class DocType(str, Enum):
    statement = "statement"
    loan_agreement = "loan_agreement"
    closure_letter = "closure_letter"
    unknown = "unknown"


class ValueType(str, Enum):
    text = "text"
    date = "date"
    money = "money"
    account = "account"


class BBox(BaseModel):
    """PDF points, origin top-left (pdfplumber convention)."""
    x0: float
    top: float
    x1: float
    bottom: float


class Document(BaseModel):
    doc_id: str
    path: str
    doc_type: DocType
    pages: int


class Field(BaseModel):
    """One value read from a document, with where it came from."""
    field_id: str
    doc_id: str
    name: str                      # e.g. "closure_date", "emi_amount", "txn_amount"
    value: str                     # normalised: ISO date, paise as str, last4 for accounts
    raw: str                       # text exactly as printed
    type: ValueType
    page: int                      # 0-based
    bbox: Optional[BBox] = None
    crop_path: Optional[str] = None  # relative to out/
    extractor: str = "text"        # "gemma" | "text" | "user"


class Direction(str, Enum):
    debit = "debit"
    credit = "credit"


class Transaction(BaseModel):
    txn_id: str
    doc_id: str
    date: str
    description: str
    amount: int                    # paise, always positive
    direction: Direction
    balance_after: int             # paise
    field_ids: list[str]           # [date_field, amount_field, balance_field]


class EvidenceState(str, Enum):
    confirmed = "confirmed"        # re-read matches the source and all checks pass
    reconciled = "reconciled"      # disagreement resolved by another document or the user
    unresolved = "unresolved"      # a check failed and nothing resolves it - shown, never hidden


class Check(BaseModel):
    name: str                      # "reread" | "parse" | "balance" | "cross_doc" | "user"
    passed: bool
    detail: str = ""


class Evidence(BaseModel):
    field_id: str
    state: EvidenceState
    checks: list[Check]
    reason: str


class Loan(BaseModel):
    loan_id: str
    lender: str
    account_last4: str
    start_date: Optional[str] = None
    closure_date: Optional[str] = None
    emi: Optional[int] = None      # paise
    field_ids: list[str]           # fields this loan was built from
    emi_txn_ids: list[str] = PField(default_factory=list)


class InsightKind(str, Enum):
    post_closure_emi = "post_closure_emi"
    income_stopped = "income_stopped"


class Insight(BaseModel):
    insight_id: str
    kind: InsightKind
    title: str
    loan_id: Optional[str] = None
    amount: int = 0                # paise at stake
    dates: list[str] = PField(default_factory=list)
    txn_ids: list[str] = PField(default_factory=list)
    evidence_field_ids: list[str]


class Explanation(BaseModel):
    insight_id: str
    text: str
    cited_field_ids: list[str]
    engine: str = "template"       # "gemma" | "template"


class Correction(BaseModel):
    field_id: str
    new_value: str
    user_note: str = ""


class Run(BaseModel):
    """Everything one pipeline run produces -> out/run.json."""
    case_id: str
    documents: list[Document]
    fields: list[Field]
    transactions: list[Transaction]
    evidence: list[Evidence]
    loans: list[Loan]
    insights: list[Insight]
    explanations: list[Explanation]
    corrections: list[Correction] = PField(default_factory=list)
