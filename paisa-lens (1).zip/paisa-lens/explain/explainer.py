"""Explainer. Owner: Sridaya. (Working starter by Krigv.)

Gemma 4 turns an Insight into plain language. It explains, never decides:
it only sees the cited fields, and if Gemma is unavailable a template is used.

Set PAISA_EXPLAIN=gemma to use the local model (Ollama).
CLI:  python -m explain.explainer samples/case_01
"""
from __future__ import annotations

import os
import sys
from pathlib import Path

import requests

from contracts.schemas import Explanation, Field, Insight, InsightKind

OLLAMA = os.environ.get("OLLAMA_HOST", "http://localhost:11434")
GEMMA_MODEL = os.environ.get("PAISA_GEMMA_MODEL", "gemma4")


def _rs(paise) -> str:
    return f"Rs {int(paise) / 100:,.0f}"


def _d(iso: str) -> str:
    from datetime import date
    try:
        return date.fromisoformat(iso).strftime("%-d %b %Y")
    except ValueError:
        return iso


def _template(ins: Insight, cited: dict[str, Field]) -> str:
    if ins.kind == InsightKind.post_closure_emi:
        closure = next((f.value for f in cited.values() if f.name == "closure_date"), "the closure date")
        lender = next((f.value for f in cited.values() if f.name == "lender"), "the lender")
        return (f"The closure letter says this loan with {lender} was closed on {_d(closure)}. "
                f"Your statement still shows {len(ins.dates)} EMI debits after that date "
                f"({', '.join(_d(x) for x in ins.dates)}), totalling {_rs(ins.amount)}. "
                "Each debit and the closure date are shown with their source crops, "
                "so you can ask the lender for a refund with this evidence.")
    if ins.kind == InsightKind.income_stopped:
        return (f"Salary credits stop after {_d(ins.dates[0])}, and the statement runs to {_d(ins.dates[1])}. "
                "If income has stopped, EMIs and other fixed debits may need attention.")
    return ins.title


def _gemma(ins: Insight, cited: dict[str, Field], draft: str) -> str:
    facts = "\n".join(f"- {f.name}: {f.value}" for f in cited.values())
    prompt = ("Rewrite this finding for a borrower in 2-3 short, plain sentences. "
              "Use ONLY these facts; do not add numbers, advice or legal claims.\n"
              f"Finding: {ins.title}\nFacts:\n{facts}\nDraft: {draft}")
    r = requests.post(f"{OLLAMA}/api/generate", timeout=60, json={
        "model": GEMMA_MODEL, "prompt": prompt, "stream": False, "options": {"temperature": 0.2}})
    r.raise_for_status()
    return r.json()["response"].strip()


def explain(ins: Insight, fields: list[Field]) -> Explanation:
    cited = {f.field_id: f for f in fields if f.field_id in ins.evidence_field_ids}
    text, engine = _template(ins, cited), "template"
    if os.environ.get("PAISA_EXPLAIN") == "gemma":
        try:
            text, engine = _gemma(ins, cited, text), "gemma"
        except Exception:
            pass  # stay on the template: the demo must never break on the model
    return Explanation(insight_id=ins.insight_id, text=text,
                       cited_field_ids=list(cited), engine=engine)


if __name__ == "__main__":
    from pipeline import run
    r = run(sys.argv[1] if len(sys.argv) > 1 else "samples/case_01")
    for e in r.explanations:
        print(e.engine, "|", e.text)
