"""Generate the synthetic demo case (all names fictional, marked SAMPLE).

Story: loan XXXXXX7731 with FinSure Capital was closed on 10-05-2026,
but its EMI of Rs 12,450 keeps being debited in Jun, Jul and Aug.
Salary credits stop after June.

Run:  python samples/make_case_01.py
"""
from pathlib import Path

from reportlab.lib.pagesizes import A4
from reportlab.pdfgen import canvas

OUT = Path(__file__).parent / "case_01"
OUT.mkdir(parents=True, exist_ok=True)
W, H = A4


def inr(paise: int) -> str:
    """Indian digit grouping: 400000.00 -> 4,00,000.00"""
    rupees, p = divmod(paise, 100)
    s = str(rupees)
    if len(s) > 3:
        head, tail = s[:-3], s[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        s = ",".join(groups) + "," + tail
    return f"{s}.{p:02d}"


def header(c, title, sub):
    c.setFont("Helvetica-Bold", 16)
    c.drawString(72, H - 72, title)
    c.setFont("Helvetica", 9)
    c.drawString(72, H - 88, sub)
    c.setFont("Helvetica-Oblique", 8)
    c.drawRightString(W - 72, H - 72, "SAMPLE DOCUMENT - FICTIONAL DATA")


def kv(c, y, label, value):
    c.setFont("Helvetica", 10)
    c.drawString(72, y, label)
    c.setFont("Helvetica-Bold", 10)
    c.drawString(250, y, value)


def statement():
    rows = []
    bal = 8500000
    rows.append(("01-03-2026", "OPENING BALANCE", None, None, bal))
    for m in ["03", "04", "05", "06", "07", "08"]:
        if m in ("03", "04", "05", "06"):
            bal += 6200000
            rows.append((f"01-{m}-2026", "SALARY NEFT ACME SYSTEMS", None, 6200000, bal))
        bal -= 1245000
        rows.append((f"05-{m}-2026", "EMI LOAN XXXXXX7731 FINSURE", 1245000, None, bal))
        bal -= 1800000
        rows.append((f"07-{m}-2026", "RENT UPI SHARMA", 1800000, None, bal))
        bal -= 640000
        rows.append((f"15-{m}-2026", "UPI GROCERY MART", 640000, None, bal))

    c = canvas.Canvas(str(OUT / "statement.pdf"), pagesize=A4)
    header(c, "SAVINGS ACCOUNT STATEMENT", "Demo Bank  |  Account XXXXXXXX2290  |  Arun Prakash  |  01-03-2026 to 31-08-2026")
    cols = [72, 150, 360, 430, 500]
    y = H - 130
    c.setFont("Helvetica-Bold", 9)
    for x, t in zip(cols, ["Date", "Description", "Debit", "Credit", "Balance"]):
        c.drawString(x, y, t)
    c.setFont("Helvetica", 9)
    for d, desc, dr, cr, b in rows:
        y -= 20
        c.drawString(cols[0], y, d)
        c.drawString(cols[1], y, desc)
        if dr:
            c.drawString(cols[2], y, inr(dr))
        if cr:
            c.drawString(cols[3], y, inr(cr))
        c.drawString(cols[4], y, inr(b))
    c.save()


def agreement():
    c = canvas.Canvas(str(OUT / "loan_agreement.pdf"), pagesize=A4)
    header(c, "LOAN AGREEMENT - KEY TERMS", "FinSure Capital Ltd  |  Personal Loan")
    y = H - 140
    for label, value in [
        ("Lender", "FinSure Capital Ltd"),
        ("Borrower", "Arun Prakash"),
        ("Loan Account No", "XXXXXX7731"),
        ("Sanction Date", "05-06-2024"),
        ("Principal", "Rs " + inr(40000000)),
        ("EMI Amount", "Rs " + inr(1245000)),
        ("Tenure", "36 months"),
        ("EMI Due Date", "5th of every month"),
    ]:
        kv(c, y, label, value)
        y -= 24
    c.save()


def closure():
    c = canvas.Canvas(str(OUT / "closure_letter.pdf"), pagesize=A4)
    header(c, "LOAN CLOSURE CERTIFICATE", "FinSure Capital Ltd  |  No Dues Certificate")
    y = H - 140
    for label, value in [
        ("Borrower", "Arun Prakash"),
        ("Loan Account No", "XXXXXX7731"),
        ("Closure Date", "10-05-2026"),
        ("Outstanding Amount", "Rs " + inr(0)),
    ]:
        kv(c, y, label, value)
        y -= 24
    c.setFont("Helvetica", 10)
    c.drawString(72, y - 20, "This is to certify that the above loan account is fully repaid and closed.")
    c.drawString(72, y - 36, "No further EMI is payable by the borrower.")
    c.save()


if __name__ == "__main__":
    statement()
    agreement()
    closure()
    print("wrote", sorted(p.name for p in OUT.glob("*.pdf")))
